﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace denemekicin1.Controllers
{
    public class AIController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IWebHostEnvironment _environment;

        public AIController(IHttpClientFactory httpClientFactory, IWebHostEnvironment environment)
        {
            _httpClientFactory = httpClientFactory;
            _environment = environment;
        }

        [HttpGet]
        public IActionResult GetHairStyleSuggestions()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetHairStyleSuggestions(
            string faceShape,
            string skinType,
            string hairLength,
            string naturalHairColor,
            string additionalFeatures,
            IFormFile uploadedPhoto)
        {
            if (string.IsNullOrEmpty(faceShape) || string.IsNullOrEmpty(skinType) || string.IsNullOrEmpty(hairLength) || string.IsNullOrEmpty(naturalHairColor))
            {
                ViewBag.Error = "Lütfen tüm zorunlu bilgileri eksiksiz doldurun.";
                return View();
            }

            string photoPath = null;

            // Fotoğrafı kaydetme işlemi
            if (uploadedPhoto != null && uploadedPhoto.Length > 0)
            {
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadsFolder); // Uploads klasörünü oluştur
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(uploadedPhoto.FileName);
                photoPath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(photoPath, FileMode.Create))
                {
                    await uploadedPhoto.CopyToAsync(stream);
                }
            }

            // Kullanıcı bilgilerini API'ye gönder
            var apiResponse = await GetSuggestionsFromAI(faceShape, skinType, hairLength, naturalHairColor, additionalFeatures, photoPath);

            ViewBag.Response = apiResponse;

            return View("Result");
        }

        private async Task<string> GetSuggestionsFromAI(
            string faceShape,
            string skinType,
            string hairLength,
            string naturalHairColor,
            string additionalFeatures,
            string photoPath)
        {
            var client = _httpClientFactory.CreateClient();

            // OpenAI API ayarları
            var apiUrl = "";
            var apiKey = "";

            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", apiKey);

            // Fotoğraf bilgisi eklemek isterseniz bunu ekleyebilirsiniz:
            var additionalPhotoInfo = photoPath != null ? $"Fotoğraf yüklendi: {photoPath}" : "Fotoğraf yüklenmedi.";

            // API'ye gönderilecek veri
            var requestBody = new
            {
                model = "gpt-3.5-turbo",
                messages = new[]
                {
                    new { role = "system", content = "Kullanıcı için saç stili öner." },
                    new { role = "user", content = $"Yüz Şekli: {faceShape}, Cilt Tipi: {skinType}, Saç Uzunluğu: {hairLength}, Doğal Saç Rengi: {naturalHairColor}, Ekstra Özellikler: {additionalFeatures}. {additionalPhotoInfo}" }
                },
                max_tokens = 500
            };

            var content = new StringContent(JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");

            // POST isteği
            var response = await client.PostAsync(apiUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                throw new Exception($"API Hatası: {response.StatusCode} - {errorContent}");
            }

            var responseContent = await response.Content.ReadAsStringAsync();
            var parsedResponse = JsonConvert.DeserializeObject<dynamic>(responseContent);

            return parsedResponse.choices[0].message.content.ToString();
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
